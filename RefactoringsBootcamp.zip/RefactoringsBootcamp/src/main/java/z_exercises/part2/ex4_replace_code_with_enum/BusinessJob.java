package z_exercises.part2.ex4_replace_code_with_enum;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class BusinessJob {

	public boolean isActive() {
		return false;
	}

	public boolean isFinished() {
		return false;
	}

}
