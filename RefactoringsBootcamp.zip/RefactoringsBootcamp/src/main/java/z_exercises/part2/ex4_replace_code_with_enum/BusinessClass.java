package z_exercises.part2.ex4_replace_code_with_enum;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class BusinessClass 
{
	public static final int JOBSTATUS_UNDEFINED = -1;
	public static final int JOBSTATUS_ACTIVE = 1;
	public static final int JOBSTATUS_FINISHED = 2;

	private static final String JOBSTATUS_UNDEFINED_NAME = "UNDEFINED";
	private static final String JOBSTATUS_ACTIVE_NAME = "Active";
	private static final String JOBSTATUS_FINISHED_NAME = "Finished";

	public static final int ERRORCODE_OK = 0;
	public static final int ERRORCODE_WARN = 1;
	public static final int ERRORCODE_ERROR = 2;

	private final BusinessJob job;

	public BusinessClass(final BusinessJob job) {
		this.job = job;
	}

	public int getJobState() {
		if (job.isActive())
			return JOBSTATUS_ACTIVE;
		if (job.isFinished())
			return JOBSTATUS_FINISHED;
		
		return JOBSTATUS_UNDEFINED;
	}
}