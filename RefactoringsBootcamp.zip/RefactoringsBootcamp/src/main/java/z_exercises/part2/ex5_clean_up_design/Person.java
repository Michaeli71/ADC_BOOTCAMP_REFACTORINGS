package z_exercises.part2.ex5_clean_up_design;

import java.util.ArrayList;
import java.util.List;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Person 
{
	String name;
	int age;
	
	List<Address> addresses = new ArrayList<>();
	
	public Person()
	{		
	}
	
	public void personInit(String name, int age)
	{		
		name = name;
		age = age;
	}

	
	public void setFirstAddress(Address address) 
	{	
		addresses.add(address);
	}	
	
	public void printAddresses()
	{
		for (Address address : addresses)
		{
			System.out.println("City: " + address.city);
			System.out.println("Country: " + address.country);
		}
	}

	@Override
	public String toString() 
	{
		return "Person [name=" + name + ", age=" + age + ", addresses=" + addresses + "]";
	}
}
