package z_exercises.part2.ex5_clean_up_design;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class AddressPrinterApp
{
	public static void main(final String[] args) 
	{		
		final Person karthi = new Person();
		karthi.personInit("Karthi", 33);

		final Person mike = new Person();
		mike.personInit("Mike", 46);
		mike.setFirstAddress(new Address("Zürich", "Switzerland"));
		mike.setFirstAddress(new Address("Aachen", "Germany"));
		
		System.out.println(karthi);
		System.out.println(mike);
		
		System.out.println("\nMIke's addresses:");
		mike.printAddresses();
	}
}
