package z_exercises.part2.ex5_clean_up_design;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Address
{
	public final String city;
	String country;

	String street;

	Address(String city, String country)
	{
		this.city = city;
		this.country = country;
	}
}
