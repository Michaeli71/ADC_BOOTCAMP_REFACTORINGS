package z_exercises.part2.ex1;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
// Which Smell?
public class PersonPrinter {

	public static void main(String[] args) {
		Person mike = new Person();
		mike.name = "Mike";
		mike.age = 51;

		System.out.println("Person "  + mike.name + " is " + mike.age + " years old.");
	}
}
