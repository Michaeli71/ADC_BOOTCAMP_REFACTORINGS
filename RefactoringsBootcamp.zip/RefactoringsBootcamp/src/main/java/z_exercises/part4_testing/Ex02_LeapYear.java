package z_exercises.part4_testing;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Ex02_LeapYear
{
    public static void main(String[] args)
    {
        for (int year = 1900; year < 2021; year++)
        {
            if (isLeap(year))
            {
                System.out.println("year: " + year);
            }
        }
    }

    public static boolean isLeap(final int year)
    {
        final boolean everyFourthYear = year % 4 == 0;
        final boolean isSecular = year % 100 == 0;
        final boolean isSecularSpecial = isSecular && year % 400 == 0;

        return everyFourthYear && !isSecular || isSecularSpecial;
    }
}
