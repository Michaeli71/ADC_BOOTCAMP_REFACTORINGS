package z_exercises.part4_testing;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class MinOf4 {

	public static void main(String[] args) {

		//
		System.out.println("minOf3");
		System.out.println(minOf3_correct(1, 2, 3));
		System.out.println(minOf3_correct(3, 1, 2));
		System.out.println(minOf3_correct(2, 3, 1));
		System.out.println(minOf3_correct(2, 1, 3));

		// -------------------------
		System.out.println("minOf4");
		System.out.println(specialMinOf4(1, 2, 3, 4));
		System.out.println(specialMinOf4(4, 1, 2, 3));
		System.out.println(specialMinOf4(3, 4, 1, 2));
		System.out.println(specialMinOf4(2, 3, 4, 1));

		System.out.println(specialMinOf4(2, 1, 3, 4));
		System.out.println(specialMinOf4(2, 1, 4, 3));
		System.out.println(specialMinOf4(2, 3, 1, 4));
		System.out.println(specialMinOf4(2, 3, 4, 1));
		System.out.println(specialMinOf4(2, 4, 1, 3));
		System.out.println(specialMinOf4(2, 4, 3, 1));

		// ups
		System.out.println(specialMinOf4(3, 4, 2, 1));
		System.out.println(specialMinOf4(4, 3, 2, 1));
	}

	private static int minOf4(int a, int b, int c, int d) {
		return Math.min(a, Math.min(b, Math.min(c, d)));
	}

	// mit Pin Down und schrittweise umformen
	private static int specialMinOf4(int a, int b, int c, int d) {
		if (a < b && a >= c)
			return c;
		if (a >= b && b >= c)
			return c;

		return Math.min(a, Math.min(b, d));
	}

	private static int specialMinOf4_MOD(int a, int b, int c, int d) {

		if (a < b) {
			if (a < c) {
//				if (a < d)
//					return a;
//				else
//					return d;
				return Math.min(a, d);
			} else {
				return c;
			}
		} else // a >= b
		{
			if (b < c) {
//				if (b < d)
//					return b;
//				else
//					return d;
				return Math.min(b, d);
			} else {
				return c;
			}
		}
	}

	private static int specialMinOf4_OLD(int a, int b, int c, int d) {

		if (a < b) {
			if (a < c) {
				if (a < d)
					return a;
				else
					return d;
			} else {
				return c;
			}
		} else // a >= b
		{
			if (b < c) {
				if (b < d)
					return b;
				else
					return d;
			} else {
				return c;
			}
		}
	}

	// correct
	private static int minOf4_correct(int a, int b, int c, int d) {

		if (a < b) {
			if (a < c) {
				if (a < d)
					return a;
				else
					return d;
			} else {
				if (c < d)
					return c;
				else
					return d;
			}
		} else // a >= b
		{
			if (b < c) {
				if (b < d)
					return b;
				else
					return d;
			} else {
				if (c < d)
					return c;
				else
					return d;
			}
		}
	}

	//
	private static int minOf3_correct(int x, int y, int z) {

		if (x < y) {
			if (x < z) {
				return x;
			} else {
				return z;
			}
		} else {
			if (y < z) {
				return y;
			} else {
				return z;
			}
		}
	}

	// 1) händisch else durch if a >= b ersetzen
	// 2) remove braces => statement
	// 3) remove redudant else => gibt es in Eclipsen icht
	// 4) händisch if duplizieren
	// 5) Merge nested if => join if
	// 6) Move up, wegen Data flow
	// 7) Merge nested if => join if
	private static int specialMinOf4_STEP2(int a, int b, int c, int d) {

		if (a < b && a >= c)		
			return c;
		if (a >= b && b >= c)
			return c;

		if (a < b)
			return Math.min(a, d);
		else
			return Math.min(b, d);
	}

	private static int specialMinOf4_STEP3(int a, int b, int c, int d) {

		if (a < b) {
			if (a >= c) {
				return c;
			} else {
				return Math.min(a, d);
			}
		} else // a >= b
		{
			if (b >= c) {
				return c;
			} else {
				return Math.min(b, d);
			}
		}
	}
}
