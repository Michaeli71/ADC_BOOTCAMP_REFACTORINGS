package z_exercises.part4_testing;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Ex03_RomanNumbers
{
    public static void main(String[] args)
    {
        System.out.println(fromRomanNumber("I")); // => 1
        System.out.println(fromRomanNumber("II")); // => 2
        System.out.println(fromRomanNumber("VII")); // => 7

        // SUbtraktionsregel
        System.out.println(fromRomanNumber("IX")); // => 9
        System.out.println(fromRomanNumber("XC")); // => 90
        System.out.println(fromRomanNumber("CD")); // => 400

        System.out.println(fromRomanNumber("CCIIIVXXX")); // => 222

        System.out.println(fromRomanNumber("MMXVIIII")); // = 2019
        System.out.println(fromRomanNumber("MCMLXXI")); // = 1971
        System.out.println(fromRomanNumber("MDCCCCLXXXIIII")); // = 1984
        System.out.println(fromRomanNumber("MCMLXXXIV")); // = 1984
        System.out.println(toRomanNumber(1984)); // => MCMLXXXIV
    }

    static Map<Character, Integer> valueMap = Map.of('I', 1, 'V', 5, 'X', 10, 'L', 50, 'C', 100, 'D', 500, 'M', 1000);

    public static int fromRomanNumber(final String romanNumber)
    {
        int value = 0;
        int lastDigitValue = 0;

        for (int i = romanNumber.length() - 1; i >= 0; i--)
        {
            final char romanDigit = romanNumber.charAt(i);
            final int digitValue = valueMap.getOrDefault(romanDigit, 0);

            final boolean addMode = digitValue >= lastDigitValue;
            if (addMode)
            {
                value += digitValue;
                lastDigitValue = digitValue;
            }
            else
            {
                value -= digitValue;
            }
        }
        return value;
    }

    public static String toRomanNumber(int value)
    {
        String result = "";
        int reminder = value;

        // absteigende Sortierung
        final Comparator<Integer> reversed = Comparator.reverseOrder();
        final Map<Integer, String> sortedIntToRomanDigit = new TreeMap<>(reversed);
        sortedIntToRomanDigit.putAll(intToRomanDigitMapS);

        // mit grösstem Wert starten
        final Iterator<Map.Entry<Integer, String>> it = sortedIntToRomanDigit.entrySet().iterator();

        while (it.hasNext() && reminder > 0)
        {
            final Map.Entry<Integer, String> entry = it.next();
            final String romanDigitCombi = entry.getValue();

            final int multiplier = entry.getKey();
            final int times = reminder / multiplier;

            reminder = reminder % multiplier;

            result += romanDigitCombi.repeat(times);
        }

        return result;
    }

    static Map<Integer, String> intToRomanDigitMapS = new TreeMap<>()
    {
        {
            put(1, "I");
            put(4, "IV");
            put(5, "V");
            put(9, "IX");
            put(10, "X");
            put(40, "XL");
            put(50, "L");
            put(90, "XC");
            put(100, "C");
            put(400, "CD");
            put(500, "D");
            put(900, "CM");
            put(1000, "M");
        }
    };
}
