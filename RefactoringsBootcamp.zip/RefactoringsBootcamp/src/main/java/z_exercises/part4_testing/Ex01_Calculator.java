package z_exercises.part4_testing;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Ex01_Calculator
{
    public Ex01_Calculator()
    {
    }

    public int add(int value1, int value2)
    {
        return value1 + value2;
    }

    public int divide(int value1, int value2)
    {
        return value1 / value2;
    }
    
    public double sumUp_0_1(final int factor)
    {
        double value = 0.1;
        
        double result = 0;
        for (int i = 0; i < factor; i++)
        {
            result += value;
        }
        return result;
    }
}
