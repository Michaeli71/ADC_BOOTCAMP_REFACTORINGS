package z_exercises.part5.ex1;

import java.time.LocalDateTime;

import z_exercises.part5.ex1.external.ComplexFrequency;
import z_exercises.part5.ex1.external.ExtTimePeriod;

/**
 * Beispiel für eine Kombination von Basis-Refactorings
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014, 2020 by Michael Inden 
 */
public class TimeStampUtils 
{
	public static String createTimeStampString(final ExtTimePeriod currentPeriod, 
					                           final ComplexFrequency frequency) 
	{
		final LocalDateTime start = currentPeriod.getDateTime();

		final int divisor = frequency == ComplexFrequency.P1M ? 1 : 3;
		final String addition = frequency == ComplexFrequency.P1M ? "" : "Q";
		final int value = ((start.getMonthValue() - 1) / divisor + 1);

		return start.getYear() + "-" + addition + value;
	}
}
