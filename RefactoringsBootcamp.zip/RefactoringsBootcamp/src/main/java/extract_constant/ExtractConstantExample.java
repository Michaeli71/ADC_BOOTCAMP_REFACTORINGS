package extract_constant;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class ExtractConstantExample {

//	private static final double PI = 3.1415;
//	
//	public double calc_better(int x, int y)
//	{
//		return x * y * PI;
//	}

	private static final double PI = 3.1415;
	
	public double calc(int x, int y)
	{
		return x * y * PI;
	}
}
