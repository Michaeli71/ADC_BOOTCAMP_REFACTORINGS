package intro;

import java.util.Objects;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public final class NumberUtilsV3NullInputCorrected
{
	public static boolean isNumber(final String value) 
	{
		Objects.requireNonNull(value, "parameter 'value' must not be null");

		if (value.isEmpty())
		{
			return false;
		}
		if (Character.isDigit(value.charAt(0))) 
		{
			for (int i = 1, n = value.length(); i < n; i++) 
			{
				if (!(Character.isDigit(value.charAt(i)))) 
				{
					return false;
				}
			}
		} 
		else 
		{
			return false;
		}
		return true;
	}
}