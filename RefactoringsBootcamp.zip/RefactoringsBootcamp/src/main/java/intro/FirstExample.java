package intro;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class FirstExample {

	public static void main(String[] args) {
		
		badReadability(7, 2);
		goodReadability(7, 2);
	}

	private static void badReadability(int b, int h)
	{
		double x = 2 * (b + h);
		System.out.println("Umfang: " + x);
		x = b * h;
		System.out.println("Fläche: " + x);
	}
	
	private static void goodReadability(int breite, int höhe)
	{
		double umfang = 2 * (breite + höhe);
		System.out.println("Umfang: " + umfang); 
		double fläche = breite * höhe; 
		System.out.println("Fläche: " + fläche);
	}

	private static void inlined(int breite, int höhe)
	{
		System.out.println("Umfang: " + (double) (2 * (breite + höhe)));
		System.out.println("Fläche: " + (double) (breite * höhe));
	}
}
