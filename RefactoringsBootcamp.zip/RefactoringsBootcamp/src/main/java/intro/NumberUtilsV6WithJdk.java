package intro;

import java.util.Objects;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public final class NumberUtilsV6WithJdk
{
    public static boolean isNumber(final String value)
    {
    	Objects.requireNonNull(value, "parameter 'value' must not be null");
    	
        try
        {
            Integer.parseInt(value); // ignore return value, just to check if its a number
            return true;
        }
        catch (final NumberFormatException ex)
        {
            return false;
        }
    }
}