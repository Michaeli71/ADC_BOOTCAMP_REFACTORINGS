package extract_local_var;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class ExtractLocalVariableExample 
{
	public double calc(int x, int y)
	{
		double factor = 3.1415;
		return x * y * factor;
	}
}
