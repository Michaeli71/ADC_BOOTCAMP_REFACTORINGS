package extract_method;

public class ExtractMethodExample {
	public void calcQuadraticEq(double a, double b, double c) {
		double D = b * b - 4 * a * c;
		if (D > 0) {
			handleDGreaterThanZero(a, b, D);
		} else if (D == 0) {
			handldDIsZero(a, b);
		} else {
			System.out.println("Equation has no roots");
		}
	}

	private void handldDIsZero(double a, double b) {
		double x;
		x = -b / (2 * a);
		System.out.println("x = " + x);
	}

	private void handleDGreaterThanZero(double a, double b, double D) {
		double x1, x2;
		x1 = (-b - Math.sqrt(D)) / (2 * a);
		x2 = (-b + Math.sqrt(D)) / (2 * a);
		System.out.println("x1 = " + x1 + ", x2 = " + x2);
	}
}
