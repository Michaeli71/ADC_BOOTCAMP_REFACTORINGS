package smells.feature_envy.step1;

class ContactInfo {
	public String getStreetName() {
		return "1 Medison Square";
	}

	public String getCity() {
		return "NewYork";
	}

	public String getState() {
		return "NY";
	}

	public String getFullAddress(ContactInfo info) {
		String city = info.getCity();// 1
		String state = info.getState();// 2
		String streetName = info.getStreetName();// 3
		return streetName + ";" + city + ";" + state;
	}
}

class User {
	private ContactInfo contactInfo;

	User(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}

	public void printAddress()
	{
		String address = contactInfo.getFullAddress(contactInfo);
		System.out.println("Address: " + address);
	}
}