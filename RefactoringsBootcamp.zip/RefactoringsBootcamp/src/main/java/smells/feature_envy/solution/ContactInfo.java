package smells.feature_envy.solution;

class ContactInfo {
	public String getStreetName() {
		return "1 Medison Square";
	}

	public String getCity() {
		return "NewYork";
	}

	public String getState() {
		return "NY";
	}

	public String getFullAddress() {
		String city = this.getCity();// 1
		String state = this.getState();// 2
		String streetName = this.getStreetName();// 3
		return streetName + ";" + city + ";" + state;
	}
}

class User {
	private ContactInfo contactInfo;

	User(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}

	public void printAddress()
	{
		String address = contactInfo.getFullAddress();
		System.out.println("Address: " + address);
	}
}