package smells.feature_envy;

class ContactInfo {
	public String getStreetName() {
		return "1 Medison Square";
	}

	public String getCity() {
		return "NewYork";
	}

	public String getState() {
		return "NY";
	}
}

class User {
	private ContactInfo contactInfo;

	User(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}

	public String getFullAddress(ContactInfo info) {
		String city = info.getCity();// 1
		String state = info.getState();// 2
		String streetName = info.getStreetName();// 3
		return streetName + ";" + city + ";" + state;
	}
	
	public void printAddress()
	{
		String address = getFullAddress(contactInfo);
		System.out.println("Address: " + address);
	}
}