package change_message_signature;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class ChangeMethodSignatureExample {
	
	public double calc(double x, double y, 
			           int precision, String info)
	{
	    return x * y * 3.1415;
	}
}
