package change_message_signature;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class InrodcudeParameterExample {
	
	public double calc(int x, int y, double factor)
	{
		return x * y * factor;
	}
	
	public double calc2(int x, int y)
	{
		double factor = 3.1415;
		return x * y * factor;
	}
	
	public static void main(String[] args) {
		var result1 = new InrodcudeParameterExample().calc(2, 7, 3.1415);
		
		var result2 = new InrodcudeParameterExample().calc2(2, 7);

	}
}
