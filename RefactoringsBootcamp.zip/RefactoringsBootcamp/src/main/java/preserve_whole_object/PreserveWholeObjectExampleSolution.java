package preserve_whole_object;

public class PreserveWholeObjectExampleSolution {
	
	class Employee
	{
		public double getYearlySalary() {
			return 0;
		}

		public double getAwards() {
			return 0;
		}
		
	}
	
	public void employeeMethod(Employee employee) {
		// Some actions
		double monthlySalary = getMonthlySalary(employee);
		// Continue processing
	}

	private double getMonthlySalary(Employee employee) {
		return (employee.getYearlySalary() + employee.getAwards()) / 12;
	}
}
