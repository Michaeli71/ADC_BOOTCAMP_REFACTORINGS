package z_solutions.part4_testing;

import z_exercises.part4_testing.Ex03_RomanNumbers;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Ex03_RomanNumberAdder
{
    public static String addRomanNumber(final String romanNumber1, final String romanNumber2)
    {
        final int result = Ex03_RomanNumbers.fromRomanNumber(romanNumber1) +
                           Ex03_RomanNumbers.fromRomanNumber(romanNumber2);

        return Ex03_RomanNumbers.toRomanNumber(result);
    }
    
    public static String subtractRomanNumber(final String romanNumber1, final String romanNumber2)
    {
        final int result = Ex03_RomanNumbers.fromRomanNumber(romanNumber1) -
                           Ex03_RomanNumbers.fromRomanNumber(romanNumber2);

        return Ex03_RomanNumbers.toRomanNumber(result);
    }
}
