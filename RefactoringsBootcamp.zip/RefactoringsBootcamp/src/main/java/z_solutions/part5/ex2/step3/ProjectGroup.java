package z_solutions.part5.ex2.step3;

import java.util.ArrayList;
import java.util.List;

public class ProjectGroup extends ProjectComponent {

	private List<ProjectComponent> projectComponents = new ArrayList<>();

	public ProjectGroup(String name) {
		super(name);
	}

	public ProjectGroup(String name, List<ProjectComponent> projectComponents) {
		super(name);
		this.projectComponents = projectComponents;
	}
	
	@Override
	public int calcDuration()
	{
		int durationInDays = 0;
		
		for (var task : projectComponents)
		{
			durationInDays += task.calcDuration();			
		}
		
		return durationInDays;
	}

	public List<ProjectComponent> getTasks() {
		return projectComponents;
	}

	public void addTask(ProjectComponent tasks) {
		this.projectComponents.add(tasks);
	}
	
	public void removeTask(ProjectComponent tasks) {
		this.projectComponents.remove(tasks);
	}
}
