package z_solutions.part5.ex2.step3;

public abstract class ProjectComponent {

	private String name;
	private String comment;

	public abstract int calcDuration();

	public ProjectComponent(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}