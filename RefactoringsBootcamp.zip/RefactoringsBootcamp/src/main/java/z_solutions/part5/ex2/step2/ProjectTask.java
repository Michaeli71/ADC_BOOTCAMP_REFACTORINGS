package z_solutions.part5.ex2.step2;

public class ProjectTask extends ProjectComponent {

	private int durationInDays;
	private String comment;
	
	public ProjectTask(String name, int durationInDays) {
		super(name);
		this.durationInDays = durationInDays;
	}

	public void setDurationInDays(int durationInDays) {
		this.durationInDays = durationInDays;
	}

	@Override
	public int calcDuration() {
		return durationInDays;
	}
	
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
