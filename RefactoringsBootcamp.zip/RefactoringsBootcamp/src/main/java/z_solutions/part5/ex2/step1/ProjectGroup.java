package z_solutions.part5.ex2.step1;

import java.util.ArrayList;
import java.util.List;

public class ProjectGroup {

	private String name;
	private List<ProjectTask> tasks = new ArrayList<>();

	public ProjectGroup(String name) {
		this.name = name;
	}

	public ProjectGroup(String name, List<ProjectTask> tasks) {
		this.name = name;
		this.tasks = tasks;
	}
	
	public int calcDuration()
	{
		int durationInDays = 0;
		
		for (var task : tasks)
		{
			durationInDays += task.getDurationInDays();			
		}
		
		return durationInDays;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ProjectTask> getTasks() {
		return tasks;
	}

	public void addTask(ProjectTask tasks) {
		this.tasks.add(tasks);
	}
	
	public void removeTask(ProjectTask tasks) {
		this.tasks.remove(tasks);
	}
}
