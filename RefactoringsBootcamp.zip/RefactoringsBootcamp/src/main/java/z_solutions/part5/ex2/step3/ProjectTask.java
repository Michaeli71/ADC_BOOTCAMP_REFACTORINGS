package z_solutions.part5.ex2.step3;

public class ProjectTask extends ProjectComponent {

	private int durationInDays;
	
	public ProjectTask(String name, int durationInDays) {
		super(name);
		this.durationInDays = durationInDays;
	}

	public void setDurationInDays(int durationInDays) {
		this.durationInDays = durationInDays;
	}

	@Override
	public int calcDuration() {
		return durationInDays;
	}
}
