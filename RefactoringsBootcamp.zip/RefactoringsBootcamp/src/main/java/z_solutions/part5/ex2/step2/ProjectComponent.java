package z_solutions.part5.ex2.step2;

public abstract class ProjectComponent {

	private String name;

	public abstract int calcDuration();

	public ProjectComponent(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}