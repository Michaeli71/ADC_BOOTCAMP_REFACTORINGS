package z_solutions.part5.ex2.step1;

public class ProjectTask {

	private String name;
	private int durationInDays;
	private String comment;
	
	public ProjectTask(String name, int durationInDays) {
		this.name = name;
		this.durationInDays = durationInDays;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDurationInDays() {
		return durationInDays;
	}

	public void setDurationInDays(int durationInDays) {
		this.durationInDays = durationInDays;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
