package z_solutions.part5.ex2.step2;

import java.util.ArrayList;
import java.util.List;

public class ProjectGroup extends ProjectComponent {

	private List<ProjectTask> tasks = new ArrayList<>();

	public ProjectGroup(String name) {
		super(name);
	}

	public ProjectGroup(String name, List<ProjectTask> tasks) {
		super(name);
		this.tasks = tasks;
	}
	
	@Override
	public int calcDuration()
	{
		int durationInDays = 0;
		
		for (var task : tasks)
		{
			durationInDays += task.calcDuration();			
		}
		
		return durationInDays;
	}

	public List<ProjectTask> getTasks() {
		return tasks;
	}

	public void addTask(ProjectTask tasks) {
		this.tasks.add(tasks);
	}
	
	public void removeTask(ProjectTask tasks) {
		this.tasks.remove(tasks);
	}
}
