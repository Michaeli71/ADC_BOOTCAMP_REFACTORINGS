package z_solutions.part5.ex1.step11;

import java.time.LocalDateTime;

enum SupportedFrequencies 
{
	MONTHLY, QUARTERLY;

	public String createTimeStampString(final LocalDateTime start) {
		boolean isMonthly = this == SupportedFrequencies.MONTHLY;
		if (isMonthly) {
			return start.getYear() + "-" + "" + start.getMonthValue();
		} else {
			return start.getYear() + "-" + "Q" + ((start.getMonthValue() - 1) / 3 + 1);
		}
	}
}