package z_solutions.part5.ex1.step10;

import java.time.LocalDateTime;

/**
 * Beispiel fèr eine Kombination von Basis-Refactorings, Schritt 1
 * 
 * @author Michael Inden
 * 
 *         Copyright 2011, 2014 by Michael Inden
 */
public class TimeStampUtils {
	/**
	 * @deprecated Use {@link z_solutions.part5.ex1.step10.SupportedFrequencies#createTimeStampString(LocalDateTime)} instead
	 */
	@Deprecated
	public static String createTimeStampString(final LocalDateTime start, SupportedFrequencies frequency) {
		return frequency.createTimeStampString(start);
	}
}
