package z_solutions.part5.ex1.step8;

enum SupportedFrequencies 
{
	MONTHLY, QUARTERLY;
}