package z_solutions.part5.ex1.step9;

enum SupportedFrequencies 
{
	MONTHLY, QUARTERLY;
}