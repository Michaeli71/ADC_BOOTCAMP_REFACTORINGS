package z_solutions.part5.ex1.step5;

import z_exercises.part5.ex1.external.ComplexFrequency;
import z_exercises.part5.ex1.external.ExtTimePeriod;

public class Usage {

public static void main(String[] args) {

	final ExtTimePeriod currentPeriod = new ExtTimePeriod();
	final ComplexFrequency frequency = ComplexFrequency.P6M;
	final boolean isMonthly = frequency == ComplexFrequency.P1M;
	
	final String timeStamp = TimeStampUtils.createTimeStampString(currentPeriod, isMonthly);
	System.out.println(timeStamp);
	
	final String timeStamp2 = TimeStampUtils.createTimeStampString(currentPeriod, true);
	System.out.println(timeStamp2);
}
}
