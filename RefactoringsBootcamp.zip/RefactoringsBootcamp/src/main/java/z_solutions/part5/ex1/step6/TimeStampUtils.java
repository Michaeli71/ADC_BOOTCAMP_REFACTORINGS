package z_solutions.part5.ex1.step6;

import java.time.LocalDateTime;

/**
 * Beispiel fèr eine Kombination von Basis-Refactorings, Schritt 1
 * 
 * @author Michael Inden
 * 
 *         Copyright 2011, 2014 by Michael Inden
 */
public class TimeStampUtils {
	public static String createTimeStampString(final LocalDateTime start, final boolean isMonthly) {
		final int divisor = isMonthly ? 1 : 3;
		final String addition = isMonthly ? "" : "Q";
		final int value = ((start.getMonthValue() - 1) / divisor + 1);

		return start.getYear() + "-" + addition + value;
	}
}
