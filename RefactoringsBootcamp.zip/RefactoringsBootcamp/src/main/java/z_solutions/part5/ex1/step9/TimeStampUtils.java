package z_solutions.part5.ex1.step9;

import java.time.LocalDateTime;

/**
 * Beispiel fèr eine Kombination von Basis-Refactorings, Schritt 1
 * 
 * @author Michael Inden
 * 
 *         Copyright 2011, 2014 by Michael Inden
 */
public class TimeStampUtils {
public static String createTimeStampString(final LocalDateTime start, SupportedFrequencies frequency) {
	boolean isMonthly = frequency == SupportedFrequencies.MONTHLY;
	if (isMonthly) {
		return start.getYear() + "-" + "" + start.getMonthValue();
	} else {
		return start.getYear() + "-" + "Q" + ((start.getMonthValue() - 1) / 3 + 1);
	}
}
}
