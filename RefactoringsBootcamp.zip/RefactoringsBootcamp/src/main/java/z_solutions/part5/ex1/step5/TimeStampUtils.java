package z_solutions.part5.ex1.step5;

import java.time.LocalDateTime;

import z_exercises.part5.ex1.external.ExtTimePeriod;

/**
 * Beispiel fèr eine Kombination von Basis-Refactorings, Schritt 1
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
public class TimeStampUtils 
{
@Deprecated
public static String createTimeStampString(final ExtTimePeriod currentPeriod, final boolean isMonthly) {
	final LocalDateTime start = currentPeriod.getDateTime();
	
	return createTimeStampString(start, isMonthly);
}

public static String createTimeStampString(final LocalDateTime start, final boolean isMonthly) {
	final int divisor = isMonthly ? 1 : 3;
	final String addition = isMonthly ? "" : "Q";
	final int value = ((start.getMonthValue() - 1) / divisor + 1);

	return start.getYear() + "-" + addition + value;
}
}

