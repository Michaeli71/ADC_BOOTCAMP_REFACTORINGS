package z_solutions.part5.ex1.step1;

import z_exercises.part5.ex1.external.ComplexFrequency;
import z_exercises.part5.ex1.external.ExtTimePeriod;

public class Usage {

	public static void main(String[] args) {

		final ExtTimePeriod currentPeriod = new ExtTimePeriod();
		final ComplexFrequency frequency = ComplexFrequency.P6M;
		
		final String timeStamp = TimeStampUtils.createTimeStampString(currentPeriod, frequency);
		System.out.println(timeStamp);
		
		final String timeStamp2 = TimeStampUtils.createTimeStampString(currentPeriod, ComplexFrequency.P1M);
		System.out.println(timeStamp2);
	}
}
