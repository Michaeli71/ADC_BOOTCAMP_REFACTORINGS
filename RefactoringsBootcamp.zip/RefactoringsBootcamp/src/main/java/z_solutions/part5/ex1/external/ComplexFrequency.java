package z_solutions.part5.ex1.external;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public enum ComplexFrequency 
{
	P1D, P1W, P1M, P3M, P6M, P1Y;
}
