package z_solutions.part5.ex1.step7;

enum SupportedFrequencies 
{
	MONTHLY, QUARTERLY;
}