package z_solutions.part5.ex1.step9;

import java.time.LocalDateTime;

/**
 * Beispiel fèr eine Kombination von Basis-Refactorings, Schritt 1
 * 
 * @author Michael Inden
 * 
 *         Copyright 2011, 2014 by Michael Inden
 */
public class TimeStampUtils2 {
public static String createTimeStampString(final LocalDateTime start, SupportedFrequencies frequency) {
	boolean isMonthly = frequency == SupportedFrequencies.MONTHLY;
	final int divisor;
	final String addition;
	if (isMonthly) {
		divisor = 1;
		addition = "";
		
		final int value = ((start.getMonthValue() - 1) / divisor + 1);

		return start.getYear() + "-" + addition + value;
	} else {
		addition = "Q";
		divisor = 3;
		
		final int value = ((start.getMonthValue() - 1) / divisor + 1);

		return start.getYear() + "-" + addition + value;
	}
}
}
