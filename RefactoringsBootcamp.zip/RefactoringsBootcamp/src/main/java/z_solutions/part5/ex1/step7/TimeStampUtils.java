package z_solutions.part5.ex1.step7;

import java.time.LocalDateTime;

/**
 * Beispiel fèr eine Kombination von Basis-Refactorings, Schritt 1
 * 
 * @author Michael Inden
 * 
 *         Copyright 2011, 2014 by Michael Inden
 */
public class TimeStampUtils {
	
	// boolean parameters are ugly
	// https://betterprogramming.pub/dont-use-boolean-arguments-use-enums-c7cd7ab1876a
	public static String createTimeStampString(final LocalDateTime start, SupportedFrequencies frequency) {
		boolean isMonthly = frequency == SupportedFrequencies.MONTHLY;
		final int divisor = isMonthly ? 1 : 3;
		final String addition = isMonthly ? "" : "Q";
		final int value = ((start.getMonthValue() - 1) / divisor + 1);
	
		return start.getYear() + "-" + addition + value;
	}
	
	// Remedy 1: Define constants
	
	public static final boolean MONTHLY = true; 
	public static final boolean QUARTERLY = false;

	// Remedy 2: Define helper method (not possible any longer without dependency to ComplexFrequency)

	/*
	private static boolean isMonthly(final ComplexFrequency frequency)
	{
		return frequency == ComplexFrequency.P1M; 
	}
	*/

	// Remedy 2: Define helper methods 
	
	private static boolean monthly() {
		return true;
	}

	private static boolean quarterly() {
		return false;
	}

}
