package z_solutions.part5.ex1.step9;

import java.time.LocalDateTime;

import z_exercises.part5.ex1.external.ExtTimePeriod;

public class Usage {

public static void main(String[] args) {

	final ExtTimePeriod currentPeriod = new ExtTimePeriod();
	final LocalDateTime start = currentPeriod.getDateTime();
	
	final String timeStamp = TimeStampUtils.createTimeStampString(start, SupportedFrequencies.QUARTERLY);
	System.out.println(timeStamp);
	
	final String timeStamp2 = TimeStampUtils.createTimeStampString(start, SupportedFrequencies.MONTHLY);
	System.out.println(timeStamp2);
}
}
