package z_solutions.part2.ex2_long_parameterlist.step2;

public class PollutionData2 {
	private Float average;
	private Float max;
	private Float min;
	private String pollutant;

	public PollutionData2(Float average, Float max, Float min, String pollutant) {
		this.average = average;
		this.max = max;
		this.min = min;
		this.pollutant = pollutant;
	}

	public Float getAverage() {
		return average;
	}

	public void setAverage(Float average) {
		this.average = average;
	}

	public Float getMax() {
		return max;
	}

	public void setMax(Float max) {
		this.max = max;
	}

	public Float getMin() {
		return min;
	}

	public void setMin(Float min) {
		this.min = min;
	}

	public String getPollutant() {
		return pollutant;
	}

	public void setPollutant(String pollutant) {
		this.pollutant = pollutant;
	}
}