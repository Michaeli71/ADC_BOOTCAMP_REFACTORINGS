package z_solutions.part2.ex2_long_parameterlist.step2;

import java.time.LocalDateTime;

// 1) Introduce Parameter Object Location2
// 2) Introduce Parameter Object PollutionData2
class PollutantEntry {
    Location location = new Location();
	LocalDateTime lastUpdate;
    PollutionData pollutionData = new PollutionData();

	public PollutantEntry(Location2 location, LocalDateTime lastUpdate, PollutionData2 pollutionData) {
        this.location.setCountry(location.getCountry());
        this.location.setState(location.getState());
        this.location.setCity(location.getCity());
        this.location.setPlace(location.getPlace());
        this.lastUpdate = lastUpdate;
        this.pollutionData.setAverage(pollutionData.getAverage());
        this.pollutionData.setMax(pollutionData.getMax());
        this.pollutionData.setMin(pollutionData.getMin());
        this.pollutionData.setPollutant(pollutionData.getPollutant());
    }
}