package z_solutions.part2.ex2_long_parameterlist.step1;

import java.time.LocalDateTime;

// 1) Extract class Location
// 2) Extract class PollutionData
// 3) Rename LocalDateTime field + parameter to lastUpdate
class PollutantEntry {
    Location location = new Location();
	LocalDateTime lastUpdate;
    PollutionData pollutionData = new PollutionData();

	public PollutantEntry(String country, String state, String city, String place, LocalDateTime lastUpdate, Float average, Float max, Float min, String pollutant) {
        this.location.setCountry(country);
        this.location.setState(state);
        this.location.setCity(city);
        this.location.setPlace(place);
        this.lastUpdate = lastUpdate;
        this.pollutionData.setAverage(average);
        this.pollutionData.setMax(max);
        this.pollutionData.setMin(min);
        this.pollutionData.setPollutant(pollutant);
    }
}