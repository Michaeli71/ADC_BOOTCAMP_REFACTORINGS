package z_solutions.part2.ex2_long_parameterlist.step3;

import java.time.LocalDateTime;

// 1) Change method signature
// 2) BY Hand: Remove "unused" class(es) Location2 / PollutionData2
// 3) BY Hand: Replace field assignments with class assignment 
// 4) Encapsulate fields for Location / PollutionData
class PollutantEntry {
    private Location location = new Location();
	private LocalDateTime lastUpdate;
    private PollutionData pollutionData = new PollutionData();

	public PollutantEntry(Location location, LocalDateTime lastUpdate, PollutionData pollutionData) {
        this.setLocation(location);
        this.setLastUpdate(lastUpdate);
        this.setPollutionData(pollutionData);
    }

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public LocalDateTime getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(LocalDateTime lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public PollutionData getPollutionData() {
		return pollutionData;
	}

	public void setPollutionData(PollutionData pollutionData) {
		this.pollutionData = pollutionData;
	}
}