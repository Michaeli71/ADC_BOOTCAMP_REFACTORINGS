package z_solutions.part2.ex2_long_parameterlist.step2;

public class Location {
	private String country;
	private String state;
	private String city;
	private String place;

	public Location() {
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public void fromLocation(Location location) {
		setCountry(location.getCountry());
	    setState(location.getState());
	    setCity(location.getCity());
	    setPlace(location.getPlace());
	}
}