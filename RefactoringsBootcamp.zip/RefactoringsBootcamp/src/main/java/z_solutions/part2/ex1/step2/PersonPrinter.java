package z_solutions.part2.ex1.step2;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
// Which Smell? => Feature Envy
// a) Extract Method
// b) Rename Parameter => person
// b) Move method => Person class
public class PersonPrinter {

	public static void main(String[] args) {
		Person mike = new Person();
		mike.setName("Mike");
		mike.setAge(51);

		Person.printPersonInfo(mike);
	}
}
