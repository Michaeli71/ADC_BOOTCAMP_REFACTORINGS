package z_solutions.part2.ex1.step3;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
// a) Generate constructor
// b) Generate constructor
// c) static => instance method, 
// c1) Extract method printPerson
// c2) BY HAND: person. vor method
// c3) remove static modifier
// c4) introduce local var
// c5) BY HAND: person2 = this
// c6) change method signature
// c7) Inline "printPersonInfo"
// c8) Inline local var
public class Person {

	private String name;
	private int age;
	
	
	public Person() {
	}

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public static void main(String[] args) {
		Person mike = new Person("Mike", 51);
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void printPerson() {
		System.out.println("Person "  + this.getName() + " is " + this.getAge() + " years old.");
	}
}
