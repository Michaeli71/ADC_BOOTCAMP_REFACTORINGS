package z_solutions.part2.ex1.step1;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
// 1) Encapsulate field x 2
public class Person {

	private String name;
	private int age;
	
	public static void main(String[] args) {
		Person mike = new Person();
		mike.setName("Mike");
		mike.setAge(51);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
}
