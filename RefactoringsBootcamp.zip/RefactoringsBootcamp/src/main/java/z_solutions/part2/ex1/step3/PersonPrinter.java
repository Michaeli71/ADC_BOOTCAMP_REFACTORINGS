package z_solutions.part2.ex1.step3;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
// Which Smell? => Feature Envy / Intimicy
public class PersonPrinter {

	public static void main(String[] args) {
		Person mike = new Person("Mike", 51);

		mike.printPerson();
	}
}
