package z_solutions.part2.ex1.step1;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
// Which Smell?
public class PersonPrinter {

	public static void main(String[] args) {
		Person mike = new Person();
		mike.setName("Mike");
		mike.setAge(51);

		System.out.println("Person "  + mike.getName() + " is " + mike.getAge() + " years old.");
	}
}
