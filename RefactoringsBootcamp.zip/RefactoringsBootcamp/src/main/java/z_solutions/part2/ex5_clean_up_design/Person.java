package z_solutions.part2.ex5_clean_up_design;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Person 
{
	private final String name;
	private int age;
	
	private final List<Address> addresses = new ArrayList<>();
	
	public Person(String name, int age) 
	{
		this.name = name;
		this.age = age;
	}

	public void registerAddress(Address address) 
	{	
		addresses.add(address);
	}	
	
	public void printAddresses()
	{
		addresses.forEach(address -> address.printAddress());
	}

	String getName() 
	{
		return name;
	}

	int getAge() 
	{
		return age;
	}

	long getAgeCorrected()
	{
		final LocalDate birthday = LocalDate.of(1984, 11, 27);
		return ChronoUnit.YEARS.between(birthday, LocalDate.now());
	}
	
	void setAge(int age) 
	{
		this.age = age;
	}
	
	
	@Override
	public String toString() 
	{
		return "Person [name=" + getName() + ", age=" + getAge() + ", addresses=" + addresses + "]";
	}
}
