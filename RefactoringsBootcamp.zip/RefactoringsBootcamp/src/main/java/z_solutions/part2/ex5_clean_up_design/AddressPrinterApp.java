package z_solutions.part2.ex5_clean_up_design;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class AddressPrinterApp 
{
	public static void main(final String[] args) 
	{		
		final Person karthi = new Person("Karthi", 33);

		final Person mike = new Person("Mike", 46);
		mike.registerAddress(new Address("Zürich", "Switzerland"));
		mike.registerAddress(new Address("Aachen", "Germany"));
		
		System.out.println(karthi);
		System.out.println(mike);
		mike.printAddresses();
		
		System.out.println(karthi.getAgeCorrected());
	}
}
