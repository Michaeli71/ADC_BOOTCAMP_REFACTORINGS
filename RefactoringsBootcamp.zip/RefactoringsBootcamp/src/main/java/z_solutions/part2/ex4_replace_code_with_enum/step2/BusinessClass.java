package z_solutions.part2.ex4_replace_code_with_enum.step2;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class BusinessClass 
{
	private final BusinessJob job;

	public BusinessClass(final BusinessJob job) {
		this.job = job;
	}

	public int getJobState() {
		if (job.isActive())
			return JobStatus.JOBSTATUS_ACTIVE;
		if (job.isFinished())
			return JobStatus.JOBSTATUS_FINISHED;
		
		return JobStatus.JOBSTATUS_UNDEFINED;
	}
}