package z_solutions.part2.ex4_replace_code_with_enum.step2;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
// 1) Introduce attribute value
// 2) Create constructor
// 3) Introduce attribute name
// VARIANT 1
// ---------
// 4) Change Method Signature
// 5) BY HAND: 2 x final => compile error
// 6) Quick fix: add assignment, replace "" by name

//VARIANT 2
//---------
// 4) BY HAND: 2 x final => compile error
// 5) Quick fix: Initialize field 
public class JobStatus {

	public static final int JOBSTATUS_UNDEFINED = -1;
	public static final int JOBSTATUS_ACTIVE = 1;
	public static final int JOBSTATUS_FINISHED = 2;
	
	private static final String JOBSTATUS_FINISHED_NAME = "Finished";
	private static final String JOBSTATUS_ACTIVE_NAME = "Active";
	private static final String JOBSTATUS_UNDEFINED_NAME = "UNDEFINED";
	
	private final int value;
	private final String name; 
	
	public JobStatus(int value, String name) {
		this.value = value;
		this.name = name;
	}
}
