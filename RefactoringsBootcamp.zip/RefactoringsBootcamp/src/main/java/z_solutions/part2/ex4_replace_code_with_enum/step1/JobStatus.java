package z_solutions.part2.ex4_replace_code_with_enum.step1;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class JobStatus {

	public static final int JOBSTATUS_UNDEFINED = -1;
	public static final int JOBSTATUS_ACTIVE = 1;
	public static final int JOBSTATUS_FINISHED = 2;
	private static final String JOBSTATUS_FINISHED_NAME = "Finished";
	private static final String JOBSTATUS_ACTIVE_NAME = "Active";
	private static final String JOBSTATUS_UNDEFINED_NAME = "UNDEFINED";
}
