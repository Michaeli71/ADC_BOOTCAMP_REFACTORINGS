package z_solutions.part2.ex4_replace_code_with_enum.step3;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class ErrorCodes {

	public static final int ERRORCODE_OK = 0;
	public static final int ERRORCODE_ERROR = 2;
	public static final int ERRORCODE_WARN = 1;

}
