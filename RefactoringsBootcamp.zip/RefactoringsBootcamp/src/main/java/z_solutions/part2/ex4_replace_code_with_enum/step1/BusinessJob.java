package z_solutions.part2.ex4_replace_code_with_enum.step1;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class BusinessJob {

	public boolean isActive() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isFinished() {
		// TODO Auto-generated method stub
		return false;
	}

}
