package z_solutions.part2.ex4_replace_code_with_enum.step3;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class BusinessClass 
{
	private final BusinessJob job;

	public BusinessClass(final BusinessJob job) {
		this.job = job;
	}

	public int getJobState() {
		if (job.isActive())
			return JobStatus.ACTIVE.getValue();
		if (job.isFinished())
			return JobStatus.FINISHED.getValue();
		
		return JobStatus.UNDEFINED.getValue();
	}
}