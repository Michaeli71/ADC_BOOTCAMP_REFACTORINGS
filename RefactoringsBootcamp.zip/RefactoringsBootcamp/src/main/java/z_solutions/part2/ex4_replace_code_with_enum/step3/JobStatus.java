package z_solutions.part2.ex4_replace_code_with_enum.step3;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
// 1) 2 x Encapsulate Field
// 2) BY-HAND: 3 enum constants based on int and String constante
// 3) remove private constants
// 4) 3 x replace int constants by enum constant.getValue()
// 5) Inline of int constants => correction in business class => no more constants left
enum JobStatus
{
	UNDEFINED(-1, "Finished"), ACTIVE(1, "Active"), FINISHED(-2, "UNDEFINED");
	
	private final int value;
	private final String name; 
	
	JobStatus(int value, String name) {
		this.value = value;
		this.name = name;
	}

	public int getValue() {
		return value;
	}

	public String getName() {
		return name;
	}
}