package info_retrival_processing.step4;

import info_retrival_processing.DataElementVO;
import info_retrival_processing.DataModel;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Application {

	DataModel model = new DataModel();

public void updateModelFromElement(final DataElementVO elementVO) {
	QueueStateVO parameterObject = QueueStateVO.fromDataElementVO(elementVO);
	
	storeInModel(parameterObject);
}

public void storeInModel(QueueStateVO parameterObject) {
	model.setState(parameterObject.getState());
	model.setQueuedJobs(parameterObject.getEntryCount());
}
}
