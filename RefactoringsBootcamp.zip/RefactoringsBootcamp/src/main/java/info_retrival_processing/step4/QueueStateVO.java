package info_retrival_processing.step4;

import info_retrival_processing.DataElementVO;
import info_retrival_processing.QueueStates;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class QueueStateVO {
	private QueueStates state;
	private int entryCount;

	public QueueStateVO(QueueStates state, int entryCount) {
		this.state = state;
		this.entryCount = entryCount;
	}

	public QueueStates getState() {
		return state;
	}

	public void setState(QueueStates state) {
		this.state = state;
	}

	public int getEntryCount() {
		return entryCount;
	}

	public void setEntryCount(int entryCount) {
		this.entryCount = entryCount;
	}

	public static QueueStateVO fromDataElementVO(final DataElementVO elementVO) {
		QueueStateVO parameterObject = new QueueStateVO(QueueStates.UNREACHABLE, 0);
	
		if (elementVO != null) {
			parameterObject.setState(elementVO.getQueueStatus());
			if (parameterObject.getState() == null) {
				parameterObject.setState(QueueStates.UNKNOWN);
			}
			parameterObject.setEntryCount(elementVO.getEntryCount());		
		} 
		
		return parameterObject;
	}
}