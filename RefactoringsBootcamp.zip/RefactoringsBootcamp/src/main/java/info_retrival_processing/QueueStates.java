package info_retrival_processing;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public enum QueueStates {
	UNKNOWN, UNREACHABLE
}
