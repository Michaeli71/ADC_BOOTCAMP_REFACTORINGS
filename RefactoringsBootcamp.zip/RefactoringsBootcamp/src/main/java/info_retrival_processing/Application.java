package info_retrival_processing;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Application {

	DataModel model = new DataModel();

	public void updateModelFromElement(final DataElementVO elementVO) 
	{
	   if (elementVO != null) 
	   {
	       if (elementVO.getQueueStatus() != null) 
	       {
	           model.setState(elementVO.getQueueStatus());
	       } 
	       else 
	       {
	           model.setState(QueueStates.UNKNOWN);
	       }
	       model.setQueuedJobs(elementVO.getEntryCount());
	    } 
	    else 
	    {
	        model.setState(QueueStates.UNREACHABLE);
	        model.setQueuedJobs(0);
	    }
	}

}
