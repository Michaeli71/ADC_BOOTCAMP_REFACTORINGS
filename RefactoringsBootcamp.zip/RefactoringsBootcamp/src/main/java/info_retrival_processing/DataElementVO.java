package info_retrival_processing;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class DataElementVO {

	public QueueStates getQueueStatus() {
		return QueueStates.UNKNOWN;
	}

	public int getEntryCount() {
		// TODO Auto-generated method stub
		return 0;
	}
}
