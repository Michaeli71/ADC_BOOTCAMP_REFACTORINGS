package info_retrival_processing.step3;

import info_retrival_processing.DataElementVO;
import info_retrival_processing.DataModel;
import info_retrival_processing.QueueStates;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Application {

	DataModel model = new DataModel();

public void updateModelFromElement(final DataElementVO elementVO) {
	QueueStates state;
	int entryCount;

	if (elementVO != null) {
		state = elementVO.getQueueStatus();
		if (state == null) {
			state = QueueStates.UNKNOWN;
		}
		entryCount = elementVO.getEntryCount();		
	} else {
		state = QueueStates.UNREACHABLE;
		entryCount = 0;		
	}
	model.setState(state);
	model.setQueuedJobs(entryCount);
}
}
