package info_retrival_processing.step1;

import info_retrival_processing.DataElementVO;
import info_retrival_processing.DataModel;
import info_retrival_processing.QueueStates;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Application {

	DataModel model = new DataModel();

	public void updateModelFromElement(final DataElementVO elementVO) {
		if (elementVO != null) {
			QueueStates state = elementVO.getQueueStatus();
			if (state != null) {
				model.setState(state);
			} else {
				QueueStates state2 = QueueStates.UNKNOWN;
				model.setState(state2);
			}
			int entryCount = elementVO.getEntryCount();
			model.setQueuedJobs(entryCount);
		} else {
			QueueStates state = QueueStates.UNREACHABLE;
			model.setState(state);
			int entryCount = 0;
			model.setQueuedJobs(entryCount);
		}
	}

}
