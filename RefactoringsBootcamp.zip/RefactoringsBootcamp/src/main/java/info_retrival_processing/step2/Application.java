package info_retrival_processing.step2;

import info_retrival_processing.DataElementVO;
import info_retrival_processing.DataModel;
import info_retrival_processing.QueueStates;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Application {

	DataModel model = new DataModel();

	public void updateModelFromElement(final DataElementVO elementVO) {
		if (elementVO != null) {
			QueueStates state = elementVO.getQueueStatus();
			if (state == null) {
				state = QueueStates.UNKNOWN;
			}
			int entryCount = elementVO.getEntryCount();
			
			model.setState(state);
			model.setQueuedJobs(entryCount);
		} else {
			QueueStates state = QueueStates.UNREACHABLE;
			int entryCount = 0;
			
			model.setState(state);
			model.setQueuedJobs(entryCount);
		}
	}

}
