package pitfall_temporal_coupling;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
class TemporalCouplingExample2 {
	private String text;

	private int count;

	public void doSomething() {
		String NEW_INFO_MSG = "Very long text ....";
		setText(NEW_INFO_MSG);
		//printSummary(); // seems to not fit thematically
		if (hasExpectedLength(NEW_INFO_MSG))
			System.out.println("TEXT CHANGED: " + NEW_INFO_MSG);

		// seemingly better variant, but no longer functionally the same
		printSummary();

		String NEW_INFO_MSG_2 = "Another text ....";
		setText(NEW_INFO_MSG_2);
		if (hasExpectedLength(NEW_INFO_MSG_2))
			System.out.println("TEXT CHANGED: " + NEW_INFO_MSG_2);
	}

	private boolean hasExpectedLength(String text) {
		return text.length() == count;
	}

	public void printSummary() 
	{
		this.count = text.length();
		System.out.println("Count: " + count);
	}

	public void setText(String text) {
		this.text = text;		
	}

	public static void main(String[] args) {
		new TemporalCouplingExample2().doSomething();
	}
}
