package pitfall_temporal_coupling;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
class TemporalCouplingExample 
{
	private String text;
	private int count;

	public TemporalCouplingExample() 
	{
		methodA();
		methodB();
	}

	private void methodA() 
	{
		text = "Something";
	}

	private void methodB() 
	{
		count = text.length();
	}
	
	public static void main(String[] args) {
		new TemporalCouplingExample();
	}
}
