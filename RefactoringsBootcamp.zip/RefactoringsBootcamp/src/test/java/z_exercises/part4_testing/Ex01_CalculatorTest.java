package z_exercises.part4_testing;

import org.junit.jupiter.api.Test;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Ex01_CalculatorTest 
{
    @Test
    void test_add_normal_numbers()
    {
       // TODO
    }

    @Test
    void test_add_same_positive_and_negative_numbers_should_sum_to_zero()
    {
        // TODO
    }

    @Test
    void test_divide_by_zero_should_raise_exception()
    {
        // TODO
    }

    // TODO
}