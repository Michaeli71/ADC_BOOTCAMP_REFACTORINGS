package z_exercises.part4_testing;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Ex03_RomanNumbersTest
{
    @ParameterizedTest(name = "fromRomanNumber(''{1}'') => {0}")
    @CsvSource({ "1, I", "2, II", "3, III", "4, IV", "5, V", "7, VII", "9, IX", "17, XVII", "40, XL", "90, XC",
                 "400, CD", "444, CDXLIV", "500, D", "900, CM", "1000, M", "1666, MDCLXVI", "1971, MCMLXXI",
                 "2018, MMXVIII", "2019, MMXIX", "2020, MMXX", "3000, MMM" })
    @DisplayName("V3: Konvertiere arabische Zahl in römische Zeichen")
    void fromRomanNumber(final int arabicNumber, final String romanNumber)
    {
        final int result = Ex03_RomanNumbers.fromRomanNumber(romanNumber);

        assertEquals(arabicNumber, result);
    }

    @Test
    void fromRomanNumberWrongInput()
    {
        final int result = Ex03_RomanNumbers.fromRomanNumber("IXD");

        assertEquals(489, result);
    }

    @ParameterizedTest(name = "toRomanNumber(''{0}'') => {1}")
    @CsvSource({ "1, I", "2, II", "3, III", "4, IV", "5, V", "7, VII", "9, IX", "17, XVII", "40, XL", "90, XC",
                 "400, CD", "444, CDXLIV", "500, D", "900, CM", "1000, M", "1666, MDCLXVI", "1971, MCMLXXI",
                 "2018, MMXVIII", "2019, MMXIX", "2020, MMXX", "3000, MMM" })
    @DisplayName("Konvertiere arabische Zahl in römische Zeichen")
    void toRomanNumber(final int arabicNumber, final String romanNumber)
    {
        final String result = Ex03_RomanNumbers.toRomanNumber(arabicNumber);

        assertEquals(romanNumber, result);
    }
}