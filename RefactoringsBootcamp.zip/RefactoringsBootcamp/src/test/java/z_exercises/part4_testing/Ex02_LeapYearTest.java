package z_exercises.part4_testing;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Ex02_LeapYearTest {

	@Test
	void testIsLeap_4_Years_Rule() {
		final boolean result = Ex02_LeapYear.isLeap(2020);

		assertTrue(result);
	}

	@Test
	void testIsLeap_100_Year_Rule() {
		final boolean result = Ex02_LeapYear.isLeap(1900);

		assertFalse(result);
	}

	@Test
	void testIsLeap_400_Years_Rule() {
		final boolean result = Ex02_LeapYear.isLeap(2000);

		assertTrue(result);
	}
	
    @Test
    void test2000()
    {
        assertTrue(Ex02_LeapYear.isLeap(2000));
    }

    @Test
    void test2004()
    {
        assertTrue(Ex02_LeapYear.isLeap(2004));
    }

    @Test
    void test2012()
    {
        assertTrue(Ex02_LeapYear.isLeap(2012));
    }

    @Test
    void test1900()
    {
        assertFalse(Ex02_LeapYear.isLeap(1900));
    }

    @Test
    void test1700()
    {
        assertFalse(Ex02_LeapYear.isLeap(1700));
    }
}
