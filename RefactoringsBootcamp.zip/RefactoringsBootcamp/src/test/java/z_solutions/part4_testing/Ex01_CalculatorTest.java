package z_solutions.part4_testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import z_exercises.part4_testing.Ex01_Calculator;


/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
class Ex01_CalculatorTest
{
    @Test
    void test_add_normal_numbers()
    {
        int result = new Ex01_Calculator().add(5, 2);

        assertEquals(7, result);
    }

    @Test
    void test_add_normal_numbers_edge_case()
    {
        //int result = Math.addExact(Integer.MAX_VALUE, 7);
    	//int result = new Ex01_Calculator().add(Integer.MAX_VALUE, 7);

        //assertEquals(7, result);
        assertThrows(ArithmeticException.class, 
        		     () -> Math.addExact(Integer.MAX_VALUE, 7));
    }
    
    @Test
    @DisplayName("5 + (-5) => 0")
    void test_add_same_positive_and_negative_numbers_should_sum_to_zero()
    {
        int result = new Ex01_Calculator().add(5, -5);

        assertEquals(0, result);
    }

    @Test
    @DisplayName("DIVIDE BY 0 => EXCEPTION")
    void test_divide_by_zero_should_raise_exception()
    {
        Executable action = () -> new Ex01_Calculator().divide(7, 0);

        assertThrows(java.lang.ArithmeticException.class, action);
    }

    @Test
    @DisplayName("DIVIDE BY 0 => EXCEPTION (\"by zero\")")
    void test_message_of_exception()
    {
        Executable action = () -> new Ex01_Calculator().divide(7, 0);

        ArithmeticException thrown = assertThrows(java.lang.ArithmeticException.class, action);

        // Varianten ...
        assertTrue(thrown.getMessage().contains("by zero"));

        // better
        assertEquals("/ by zero", thrown.getMessage());

        // best Assert J
        //assertThat(thrown.getMessage()).contains("by zero");
    }
    
    @Test
    @DisplayName("0.1 + 0.1 + 0.1 = 0.3 with precison of 0.01")
    void floatingArithemticRounding() 
    {        
        double result = new Ex01_Calculator().sumUp_0_1(3);
        //System.out.println(result);
        //  0.3 = 0.1 + 0.1 + 0.1
        assertEquals(0.3, result, 0.01);
    }
}