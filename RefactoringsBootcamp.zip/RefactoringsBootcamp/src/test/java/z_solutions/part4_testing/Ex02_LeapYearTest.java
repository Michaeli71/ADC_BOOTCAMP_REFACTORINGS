package z_solutions.part4_testing;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import z_exercises.part4_testing.Ex02_LeapYear;


/**
 * Example for various workshops like Uint Testing, Refactorings, ...
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Ex02_LeapYearTest 
{
    @ParameterizedTest
    @ValueSource(ints = { 2000, 2004, 2008, 2012, 2016, 2020 })
    public void testLeap(final int year)
    {
        assertTrue(Ex02_LeapYear.isLeap(year));
    }

    @ParameterizedTest
    @ValueSource(ints = { 1700, 1800, 1900 })
    public void testSakular(final int year)
    {
        assertFalse(Ex02_LeapYear.isLeap(year));
    }
    
    
	@ParameterizedTest(name = "isLeap({0}) => {2}, Hinweis: {1}")
	@CsvSource({ "1900, Säkulär, false",
			"2000, Säkular (aber 400er Regel), true",
			"2020, jedes 4. Jahr, true" })
	void testIsLeap(int year, String hint, boolean expected) {

		final boolean result = Ex02_LeapYear.isLeap(year);

		assertEquals(expected, result);
	}

	@ParameterizedTest(name = "Schaltjahr {0}? {2}, Hinweis: {1}")
	@CsvSource({ "1900, Säkulär, \u274C, false",
			"2000, Säkular (aber 400er Regel), \u2705, true",
			"2020, jedes 4. Jahr, \u2705, true" })
	void testIsLeapNice(int year, String hint, String resultNice, boolean expected) {
		final boolean result = Ex02_LeapYear.isLeap(year);

		assertEquals(expected, result);
	}	
}
