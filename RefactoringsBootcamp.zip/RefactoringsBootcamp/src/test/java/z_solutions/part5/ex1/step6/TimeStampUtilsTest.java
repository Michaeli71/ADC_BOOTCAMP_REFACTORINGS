package z_solutions.part5.ex1.step6;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

/**
 * Beispiel für einfache Testfälle
 *  
 * @author Michael Inden
 * 
 * Copyright 2014, 2020  by Michael Inden 
 */
public class TimeStampUtilsTest 
{
	@Test
	public void test_createTimeStampString_Monthly()
	{
		final boolean MONTHLY = true;
		assertEquals("2000-2", TimeStampUtils.createTimeStampString(LocalDateTime.of(2000, 2, 7, 0, 0), MONTHLY));
		assertEquals("2000-7", TimeStampUtils.createTimeStampString(LocalDateTime.of(2000, 7, 14, 0, 0), MONTHLY));
		assertEquals("2000-12", TimeStampUtils.createTimeStampString(LocalDateTime.of(2000, 12, 24, 0, 0), MONTHLY));
	}
	
	@Test
	public void test_createTimeStampString_Quarterly()
	{
		final boolean QUARTERLY = false;
		assertEquals("2000-Q1", TimeStampUtils.createTimeStampString(LocalDateTime.of(2000, 2, 7, 0, 0), QUARTERLY));
		assertEquals("2000-Q3", TimeStampUtils.createTimeStampString(LocalDateTime.of(2000, 7, 14, 0, 0), QUARTERLY));
		assertEquals("2000-Q4", TimeStampUtils.createTimeStampString(LocalDateTime.of(2000, 12, 24, 0, 0), QUARTERLY));
	}
}
