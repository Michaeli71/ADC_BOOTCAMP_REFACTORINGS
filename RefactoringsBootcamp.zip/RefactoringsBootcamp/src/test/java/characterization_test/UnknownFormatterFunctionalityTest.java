package characterization_test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class UnknownFormatterFunctionalityTest {

// Step 1: "silly result"
@Test
public void formatsPlainText1() {
    assertEquals("XXXX", UnknownFormatterFunctionality.formatText("plain text"));
}

// Step 2: adjust "silly result" to what is delivered by method
@Test
public void formatsPlainText2() {
    assertEquals("plain text", UnknownFormatterFunctionality.formatText("plain text"));
}

// Step 3: adjust test name to gain better understanding
@Test
public void doesNotChangeUntaggedText() {
    assertEquals("plain text", UnknownFormatterFunctionality.formatText("plain text"));
}

@Test
public void emptyInput() {
    assertEquals("XXXX", UnknownFormatterFunctionality.formatText("<>")); 
}

@Test
public void removesTagTextBetweenAngleBracketPairs() {
    assertEquals("XXXX", UnknownFormatterFunctionality.formatText("<TAGGED>")); 
}

@Test
public void justKeepsContent() {
    assertEquals("XXXX", UnknownFormatterFunctionality.formatText("<TAG>CONTENT<TAG>")); 
}

// => 

@Test
public void emptyInput2() {
    assertEquals("", UnknownFormatterFunctionality.formatText("<>")); 
}

@Test
public void removesTagTextBetweenAngleBracketPairs2() {
    assertEquals("", UnknownFormatterFunctionality.formatText("<TAGGED>")); 
}

@Test
public void justKeepsContent2() {
    assertEquals("CONTENT", UnknownFormatterFunctionality.formatText("<TAG>CONTENT<TAG>")); 
}
}
